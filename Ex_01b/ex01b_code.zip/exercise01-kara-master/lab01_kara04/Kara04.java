import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Kara04 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Kara04 extends Kara
{
    /**
     * Act - do whatever the Kara04 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
        if (onLeaf())
        {
            Greenfoot.stop();
            return;
        }
        
        if (treeFront())
        {
            if (treeLeft())
                turnRight();
            else
                turnLeft();
        }
        move();    
    }    
}
